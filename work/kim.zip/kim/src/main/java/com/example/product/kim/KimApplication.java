package com.example.product.kim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KimApplication {

	public static void main(String[] args) {
		SpringApplication.run(KimApplication.class, args);
	}

}
