package com.example.product.kim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KimApplicationTests {

	@Test
	void contextLoads() {
	}

}
